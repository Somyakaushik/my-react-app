import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Gift, CreditCard, Smartphone, Users, BookOpen, Heart, Building2 } from 'lucide-react';

const DonatePage = () => {
  const [expandedDropdown, setExpandedDropdown] = useState(null);

  const toggleDropdown = (dropdown) => {
    setExpandedDropdown(expandedDropdown === dropdown ? null : dropdown);
  };

  const dropdownContent = {
    empoweringWomen: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
    literacyDrive: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
    healthCare: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
    economicDevelopment: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur."
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="bg-white shadow-lg">
        <div className="max-w-4xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex-1 mb-6 md:mb-0">
              <h1 className="text-3xl md:text-4xl font-bold mb-4" style={{ color: '#0056b3' }}>
                Giving
              </h1>
              <p className="text-gray-600 text-sm md:text-base leading-relaxed">
                Donating to Rotary means clean water and sanitation. Health and hope in areas that were once ravaged by diseases like covid. Economic development and new opportunities. Your financial help makes all this happen, and more.
              </p>
            </div>
            <div className="flex-shrink-0 ml-0 md:ml-8">
              <div className="relative">
                <div className="w-32 h-32 md:w-40 md:h-40 bg-gradient-to-br from-blue-200 to-blue-400 rounded-full flex items-center justify-center shadow-lg">
                  <div className="w-24 h-24 md:w-32 md:h-32 bg-gradient-to-br from-blue-300 to-blue-500 rounded-full flex items-center justify-center">
                    <Gift className="w-12 h-12 md:w-16 md:h-16 text-white" />
                  </div>
                </div>
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-yellow-400 rounded-full flex items-center justify-center shadow-md">
                  <span className="text-yellow-800 font-bold text-sm">₹</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <section className="mb-12">
          <h2 className="text-2xl md:text-3xl font-bold mb-6" style={{ color: '#0056b3' }}>
            Giving Options
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center mb-4">
                <CreditCard className="w-6 h-6 mr-3" style={{ color: '#0056b3' }} />
                <h3 className="text-lg font-semibold" style={{ color: '#0056b3' }}>
                  Cash/Check/Online Transfer/UPI
                </h3>
              </div>
              <p className="text-gray-600 text-sm">
                We have several options where you can donate for various projects of Rotary Club of Gundy.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center mb-4">
                <Gift className="w-6 h-6 mr-3" style={{ color: '#0056b3' }} />
                <h3 className="text-lg font-semibold" style={{ color: '#0056b3' }}>
                  Give a One-Time Gift
                </h3>
              </div>
              <p className="text-gray-600 text-sm">
                You may celebrate your special occasions like birthdays, anniversaries, etc by making a one time donation as a gift to support one of our projects.
              </p>
            </div>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl md:text-3xl font-bold mb-6" style={{ color: '#0056b3' }}>
            How to Donate
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center mb-4">
                <Smartphone className="w-6 h-6 mr-3" style={{ color: '#0056b3' }} />
                <h3 className="text-lg font-semibold" style={{ color: '#0056b3' }}>
                  UPI (PayTM/ Google Pay/ etc)
                </h3>
              </div>
              <p className="text-gray-600 text-sm mb-4">
                <strong>Beneficiary Name:</strong> ROTARY CLUB SANSKRITI MORADABAD
              </p>
              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <div className="w-full h-32 bg-gray-200 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300">
                  <span className="text-gray-500 text-sm">QR Code Image</span>
                </div>
              </div>
              <p className="text-xs text-gray-500">
                <strong>Note:</strong> <span style={{ color: '#0056b3' }}>रुपये</span> (Not applicable for 80G)
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center mb-4">
                <Building2 className="w-6 h-6 mr-3" style={{ color: '#0056b3' }} />
                <h3 className="text-lg font-semibold" style={{ color: '#0056b3' }}>
                  NEFT (For 80G Exemption)
                </h3>
              </div>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Beneficiary Name:</span>
                  <span className="font-medium">ROTARY CLUB SANSKRITI MORADABAD</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">SB A/c no:</span>
                  <span className="font-medium">513802010004015</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">IFSC:</span>
                  <span className="font-medium">UBIN0551384</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Branch:</span>
                  <span className="font-medium">OVERSEAS BRANCH, MORADABAD</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Bank:</span>
                  <span className="font-medium">UNION BANK OF INDIA</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl md:text-3xl font-bold mb-4" style={{ color: '#0056b3' }}>
            About Your Donations, Where & How They are used
          </h2>
          <p className="text-gray-600 mb-8 text-sm md:text-base">
            Projects that provide healthcare, improve developing communities, educate and empower the vulnerable and promote peace.
          </p>

          <div className="space-y-4">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <button
                onClick={() => toggleDropdown('empoweringWomen')}
                className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center">
                  <Users className="w-5 h-5 mr-3" style={{ color: '#0056b3' }} />
                  <span className="font-semibold" style={{ color: '#0056b3' }}>
                    EMPOWERING WOMEN
                  </span>
                </div>
                {expandedDropdown === 'empoweringWomen' ? (
                  <ChevronUp className="w-5 h-5" style={{ color: '#0056b3' }} />
                ) : (
                  <ChevronDown className="w-5 h-5" style={{ color: '#0056b3' }} />
                )}
              </button>
              {expandedDropdown === 'empoweringWomen' && (
                <div className="px-6 py-4 bg-gray-50 border-t">
                  <p className="text-gray-600 text-sm leading-relaxed">
                    {dropdownContent.empoweringWomen}
                  </p>
                </div>
              )}
            </div>

            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <button
                onClick={() => toggleDropdown('literacyDrive')}
                className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center">
                  <BookOpen className="w-5 h-5 mr-3" style={{ color: '#0056b3' }} />
                  <span className="font-semibold" style={{ color: '#0056b3' }}>
                    LITERACY DRIVE
                  </span>
                </div>
                {expandedDropdown === 'literacyDrive' ? (
                  <ChevronUp className="w-5 h-5" style={{ color: '#0056b3' }} />
                ) : (
                  <ChevronDown className="w-5 h-5" style={{ color: '#0056b3' }} />
                )}
              </button>
              {expandedDropdown === 'literacyDrive' && (
                <div className="px-6 py-4 bg-gray-50 border-t">
                  <p className="text-gray-600 text-sm leading-relaxed">
                    {dropdownContent.literacyDrive}
                  </p>
                </div>
              )}
            </div>

            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <button
                onClick={() => toggleDropdown('healthCare')}
                className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center">
                  <Heart className="w-5 h-5 mr-3" style={{ color: '#0056b3' }} />
                  <span className="font-semibold" style={{ color: '#0056b3' }}>
                    HEALTH CARE
                  </span>
                </div>
                {expandedDropdown === 'healthCare' ? (
                  <ChevronUp className="w-5 h-5" style={{ color: '#0056b3' }} />
                ) : (
                  <ChevronDown className="w-5 h-5" style={{ color: '#0056b3' }} />
                )}
              </button>
              {expandedDropdown === 'healthCare' && (
                <div className="px-6 py-4 bg-gray-50 border-t">
                  <p className="text-gray-600 text-sm leading-relaxed">
                    {dropdownContent.healthCare}
                  </p>
                </div>
              )}
            </div>

            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <button
                onClick={() => toggleDropdown('economicDevelopment')}
                className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center">
                  <Building2 className="w-5 h-5 mr-3" style={{ color: '#0056b3' }} />
                  <span className="font-semibold" style={{ color: '#0056b3' }}>
                    ECONOMIC AND COMMUNITY DEVELOPMENT
                  </span>
                </div>
                {expandedDropdown === 'economicDevelopment' ? (
                  <ChevronUp className="w-5 h-5" style={{ color: '#0056b3' }} />
                ) : (
                  <ChevronDown className="w-5 h-5" style={{ color: '#0056b3' }} />
                )}
              </button>
              {expandedDropdown === 'economicDevelopment' && (
                <div className="px-6 py-4 bg-gray-50 border-t">
                  <p className="text-gray-600 text-sm leading-relaxed">
                    {dropdownContent.economicDevelopment}
                  </p>
                </div>
              )}
            </div>
          </div>
        </section>

        <footer className="mt-12 pt-8 border-t border-gray-200">
          <div className="text-center text-gray-600 text-sm">
            <p>© 2025 Rotary Club Sanskriti Moradabad. All rights reserved.</p>
            <p className="mt-2">Your contributions make a difference in our community.</p>
          </div>
        </footer>
      </div>
    </div>
  );
};

export default DonatePage;